import React, { useState, useEffect } from "react";
import "./styles/main.css";
import { Routes, Route, HashRouter } from "react-router-dom";
import Header from "./components/Header";
import Footer from "./components/Footer";
import SpecificBook from "./pages/SpecificBook";
import BookList from "./pages/BookList";
import Signin from "./pages/Signin";
import { BookContext } from "./context/BookContext";
import Cart from "./pages/Cart";
import NotFound from "./pages/NotFound";
import ScrollToTop from "./utils/scrollToTop";
import data from "./utils/books.json";

export default function App() {
  const [books, setBooks] = useState([]);

  useEffect(() => {
    setBooks(data.books);
  }, []);

  return (
    <HashRouter basename="/">
      <BookContext.Provider value={books}>
        <ScrollToTop />
        <Header />
        <Routes>
          <Route path="/" element={<BookList />} />
          <Route path="/signin" element={<Signin />} />
          {/* <Route path="/cart" element={<Cart />} />
          <Route path="/specific-book/:id" element={<SpecificBook />} /> */}
          <Route path="*" element={<NotFound />} />
        </Routes>
        <Footer />
      </BookContext.Provider>
    </HashRouter>
  );
}
